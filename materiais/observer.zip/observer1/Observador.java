package observer1;

public interface Observador {

	void atualizarValorA(int valorA);
	void atualizarValorB(int valorB);
	void atualizarValorC(int valorC);

}
