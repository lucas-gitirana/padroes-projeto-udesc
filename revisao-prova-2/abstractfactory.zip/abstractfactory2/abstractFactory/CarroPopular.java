package abstractfactory2.abstractFactory;

public interface CarroPopular {
	
	void exibirInfoPopular();
	
}
