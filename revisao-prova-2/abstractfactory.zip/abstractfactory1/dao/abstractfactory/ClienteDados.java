package abstractfactory1.dao.abstractfactory;

public abstract class ClienteDados extends Dados {

}
