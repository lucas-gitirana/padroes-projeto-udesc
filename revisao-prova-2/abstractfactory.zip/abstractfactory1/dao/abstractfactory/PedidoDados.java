package abstractfactory1.dao.abstractfactory;

public abstract class PedidoDados extends Dados {

	public abstract void lerItens();
	
}
