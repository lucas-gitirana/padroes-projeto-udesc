package abstractfactory3.controle.abstractfactory;

public enum Destino {

	NORTE,
	CENTROOESTE,
	NORDESTE,
	SUDESTE,
	SUL,
	
	AMERICALATINA,
	AMERICADONORTE,
	EUROPA,
	AFRICA,
	ASIA,
	OCEANIA
	
	
	
}
